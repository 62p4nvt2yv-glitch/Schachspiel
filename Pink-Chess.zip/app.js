const board=document.getElementById("board");
const statusText=document.getElementById("status");
const mode=document.getElementById("mode");
const difficulty=document.getElementById("difficulty");
const game=new Chess();
const pieces={wk:"♔",wq:"♕",wr:"♖",wb:"♗",wn:"♘",wp:"♙",bk:"♚",bq:"♛",br:"♜",bb:"♝",bn:"♞",bp:"♟"};
const values={p:1,n:3,b:3,r:5,q:9,k:100};
// Vector pieces keep their actual colours on iOS instead of becoming emoji.
const shapes={
 p:'<circle cx="24" cy="13" r="7"/><path d="M19 20h10l3 16H16z"/>',
 r:'<path d="M12 8h7v6h4V8h4v6h4V8h6v13l-5 4 2 11H15l2-11-5-4z"/>',
 n:'<path d="M32 9 23 5l-2 7-8 9-4 9 8 3 8-9-3 12h14l-2-11c6-7 5-12-2-16Z"/><circle cx="24" cy="17" r="1.5" fill="currentColor" stroke="none"/>',
 b:'<path d="M24 5c-13 10-14 16-5 22l-4 9h18l-4-9C38 21 37 15 24 5Z"/><path d="m20 13 7 9" fill="none"/>',
 q:'<path d="m11 14 5 22h16l5-22-9 10-4-14-4 14z"/><circle cx="10" cy="12" r="3"/><circle cx="24" cy="8" r="3"/><circle cx="38" cy="12" r="3"/>',
 k:'<path d="M24 4v12m-6-7h12" fill="none" stroke-width="3"/><path d="M18 17c-12-6-12 9 0 12l-3 7h18l-3-7c12-3 12-18 0-12l-6 5z"/>'
};
const pieceNames={k:'König',q:'Dame',r:'Turm',b:'Läufer',n:'Springer',p:'Bauer'};
function pieceSVG(piece){
const fill=piece.color==='w'?'#ffffff':'#cf307a';
return `<svg viewBox="0 0 48 48" aria-hidden="true" focusable="false" style="color:#84234e"><g fill="${fill}" stroke="#84234e" stroke-width="1.5" stroke-linejoin="round" stroke-linecap="round">${shapes[piece.type]}<path d="M13 36h22v5H13zM10 41h28v3H10z"/></g></svg>`;
}
let selected=null,waiting=false,generation=0;
function draw(){
board.innerHTML="";
const legal=selected?game.moves({square:selected,verbose:true}):[];
for(let rank=8;rank>=1;rank--){
for(const file of "abcdefgh"){
const square=file+rank,piece=game.get(square);
const cell=document.createElement("button");
cell.className="square "+((rank+"abcdefgh".indexOf(file))%2===0?"dark":"light");
if(selected===square)cell.classList.add("selected");
if(legal.some(m=>m.to===square))cell.classList.add("target");
cell.innerHTML=piece?pieceSVG(piece):"";
cell.type="button";
cell.dataset.square=square;
cell.setAttribute('aria-label',square+(piece?' · '+(piece.color==='w'?'Weiß':'Pink')+' · '+pieceNames[piece.type]:' · leer')+(selected===square?' · ausgewählt':'')+(legal.some(m=>m.to===square)?' · möglicher Zug':''));
cell.setAttribute('aria-pressed',String(selected===square));
if(file==='a')cell.insertAdjacentHTML('beforeend',`<span class="coord rank" aria-hidden="true">${rank}</span>`);
if(rank===1)cell.insertAdjacentHTML('beforeend',`<span class="coord file" aria-hidden="true">${file}</span>`);
cell.onclick=()=>choose(square);
board.appendChild(cell);
}}
if(game.in_checkmate())statusText.textContent="Schachmatt! ♛";
else if(game.in_draw())statusText.textContent="Unentschieden!";
else if(waiting)statusText.textContent="Ben überlegt … 🤖";
else statusText.textContent=(game.turn()==="w"?"Weiß":"Pink")+" ist am Zug"+(game.in_check()?" – Schach!":"");
document.getElementById('undo').disabled=game.history().length===0;
difficulty.disabled=mode.value==='local';
document.getElementById('opponent').textContent=mode.value==='ben'?'Ben':'Spieler 2';
document.getElementById('opponent-detail').textContent=mode.value==='ben'?'Dein Schachpartner':'Gemeinsam an einem Brett';
document.getElementById('self').textContent=mode.value==='ben'?'Du':'Spieler 1';
}
function choose(square){
if(waiting||game.game_over())return;
if(mode.value==="ben"&&game.turn()==="b")return;
const piece=game.get(square);
if(selected){
const legal=game.moves({square:selected,verbose:true});
if(legal.some(m=>m.to===square)){
game.move({from:selected,to:square,promotion:"q"});
selected=null;draw();
if(mode.value==="ben"&&game.turn()==="b"&&!game.game_over())benMove();
return;
}}
selected=piece&&piece.color===game.turn()?square:null;
draw();
}
function evaluate(){
if(game.in_checkmate())return game.turn()==="w"?10000:-10000;
if(game.in_draw())return 0;
let score=0;
for(const row of game.board())for(const piece of row)if(piece)score+=values[piece.type]*(piece.color==="b"?1:-1);
return score;
}
function search(depth,alpha,beta){
if(depth===0||game.game_over())return evaluate();
const maximizing=game.turn()==="b";
let best=maximizing?-Infinity:Infinity;
for(const move of game.moves({verbose:true})){
game.move(move);
const score=search(depth-1,alpha,beta);
game.undo();
if(maximizing){best=Math.max(best,score);alpha=Math.max(alpha,best);}
else{best=Math.min(best,score);beta=Math.min(beta,best);}
if(beta<=alpha)break;
}
return best;
}
function benMove(){
waiting=true;draw();
const current=++generation;
setTimeout(()=>{
if(current!==generation)return;
const moves=game.moves({verbose:true});
const level=Number(difficulty.value);
let best=-Infinity,chosen=moves[0];
for(const move of moves){
game.move(move);
let score=level===1?Math.random()*20:search(level===2?1:2,-Infinity,Infinity)+Math.random()*(level===2?2:0.1);
game.undo();
if(score>best){best=score;chosen=move;}
}
if(chosen)game.move(chosen);
waiting=false;draw();
},350);
}
function resetGame(){generation++;waiting=false;selected=null;game.reset();draw();}
document.getElementById("reset").onclick=resetGame;
mode.onchange=resetGame;
document.getElementById("undo").onclick=()=>{
if(waiting){generation++;waiting=false;}
game.undo();
if(mode.value==="ben"&&game.turn()==="b")game.undo();
selected=null;draw();
};
draw();

